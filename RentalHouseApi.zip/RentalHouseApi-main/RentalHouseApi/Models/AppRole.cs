﻿using Microsoft.AspNetCore.Identity;

namespace RentalHouseApi.Models
{
    public class AppRole : IdentityRole<String>
    {
    }
}