﻿using Microsoft.AspNetCore.Identity;

namespace RentalHouseApi.Models
{
    public class AppUser : IdentityUser<String>
    {
    }
}