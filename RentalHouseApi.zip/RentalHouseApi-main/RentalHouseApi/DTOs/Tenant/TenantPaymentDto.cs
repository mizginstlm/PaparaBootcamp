namespace RentalHouseApi.DTOs.Tenant;
public class TenantPaymentDto
{
    public Guid PaymentId { get; set; }
    public DateTime DateOfPayment { get; set; }
}