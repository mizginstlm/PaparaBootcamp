﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentalHouseApi.Migrations
{
    /// <inheritdoc />
    public partial class Initiali : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Manager",
                keyColumn: "Id",
                keyValue: new Guid("09ba5236-0924-4616-a548-07cf742da616"));

            migrationBuilder.InsertData(
                table: "Manager",
                columns: new[] { "Id", "ManagerName", "PasswordHash", "PasswordSalt" },
                values: new object[] { new Guid("0afe74fd-3f6c-40b4-a1eb-c7a382b9b380"), "admin", new byte[] { 193, 55, 138, 4, 7, 208, 103, 27, 193, 44, 0, 149, 59, 33, 219, 170, 232, 24, 45, 97, 76, 202, 162, 107, 210, 166, 128, 91, 186, 185, 169, 106, 244, 198, 163, 22, 11, 34, 194, 94, 200, 186, 218, 99, 202, 84, 28, 52, 53, 115, 244, 8, 147, 188, 15, 117, 16, 47, 100, 156, 199, 255, 218, 244 }, new byte[] { 16, 15, 160, 116, 108, 58, 90, 234, 108, 71, 191, 182, 134, 15, 73, 77, 90, 88, 233, 154, 2, 76, 168, 48, 18, 200, 215, 63, 146, 138, 182, 24, 50, 177, 94, 153, 121, 174, 194, 105, 51, 199, 90, 122, 95, 232, 71, 235, 20, 194, 118, 176, 110, 221, 183, 203, 133, 191, 4, 251, 141, 160, 150, 222, 155, 102, 149, 26, 82, 53, 90, 102, 27, 243, 87, 111, 127, 18, 240, 130, 46, 165, 161, 70, 108, 86, 237, 56, 173, 75, 228, 158, 9, 155, 52, 96, 28, 168, 150, 151, 253, 78, 9, 163, 37, 30, 73, 144, 58, 221, 121, 118, 254, 211, 90, 152, 212, 55, 75, 88, 75, 48, 177, 187, 245, 6, 119, 202 } });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Manager",
                keyColumn: "Id",
                keyValue: new Guid("0afe74fd-3f6c-40b4-a1eb-c7a382b9b380"));

            migrationBuilder.InsertData(
                table: "Manager",
                columns: new[] { "Id", "ManagerName", "PasswordHash", "PasswordSalt" },
                values: new object[] { new Guid("09ba5236-0924-4616-a548-07cf742da616"), "admin", new byte[] { 92, 170, 7, 11, 132, 74, 207, 149, 16, 161, 146, 150, 250, 14, 35, 208, 209, 202, 221, 167, 175, 90, 10, 237, 7, 103, 249, 253, 190, 189, 251, 38, 202, 115, 58, 182, 232, 182, 18, 231, 33, 180, 13, 204, 62, 187, 56, 240, 18, 38, 86, 177, 1, 206, 215, 231, 247, 42, 168, 49, 185, 113, 253, 26 }, new byte[] { 81, 111, 50, 146, 57, 172, 253, 115, 101, 2, 56, 239, 29, 48, 248, 80, 52, 115, 255, 135, 242, 159, 179, 73, 170, 139, 87, 244, 173, 70, 0, 177, 123, 160, 205, 70, 35, 106, 134, 163, 135, 235, 59, 70, 94, 29, 41, 10, 184, 98, 209, 57, 36, 87, 50, 30, 35, 230, 225, 205, 36, 90, 168, 19, 53, 8, 179, 13, 69, 109, 127, 17, 99, 95, 205, 12, 171, 83, 36, 225, 196, 138, 54, 6, 222, 230, 51, 211, 50, 232, 49, 25, 126, 249, 211, 235, 16, 170, 106, 75, 167, 3, 77, 143, 131, 90, 219, 148, 47, 226, 239, 123, 58, 39, 29, 189, 214, 214, 113, 151, 196, 82, 158, 178, 152, 213, 117, 51 } });
        }
    }
}
