﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentalHouseApi.Migrations
{
    /// <inheritdoc />
    public partial class Initialid : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Apartments_ApartmentId",
                table: "Payments");

            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Tenants_TenantId",
                table: "Payments");

            migrationBuilder.DropIndex(
                name: "IX_Payments_ApartmentId",
                table: "Payments");

            migrationBuilder.DeleteData(
                table: "Manager",
                keyColumn: "Id",
                keyValue: new Guid("0afe74fd-3f6c-40b4-a1eb-c7a382b9b380"));

            migrationBuilder.DropColumn(
                name: "ApartmentId",
                table: "Payments");

            migrationBuilder.DropColumn(
                name: "Tenant",
                table: "Payments");

            migrationBuilder.AlterColumn<Guid>(
                name: "TenantId",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);

            migrationBuilder.InsertData(
                table: "Manager",
                columns: new[] { "Id", "ManagerName", "PasswordHash", "PasswordSalt" },
                values: new object[] { new Guid("670dfbac-7729-42fa-afe2-c232a876a082"), "admin", new byte[] { 168, 126, 209, 65, 202, 233, 123, 242, 40, 127, 93, 217, 237, 57, 221, 135, 71, 71, 214, 50, 143, 13, 196, 139, 127, 75, 156, 236, 51, 214, 146, 2, 43, 123, 204, 56, 225, 235, 158, 14, 155, 94, 178, 133, 101, 200, 109, 189, 82, 143, 73, 252, 16, 217, 28, 177, 212, 12, 252, 56, 187, 78, 149, 45 }, new byte[] { 12, 26, 77, 124, 209, 146, 237, 48, 197, 172, 58, 35, 174, 254, 241, 121, 100, 233, 42, 184, 107, 81, 17, 130, 201, 247, 17, 4, 226, 120, 239, 213, 64, 43, 22, 189, 63, 55, 53, 104, 102, 254, 136, 176, 15, 184, 250, 162, 216, 130, 82, 95, 182, 100, 135, 129, 254, 5, 200, 52, 162, 180, 120, 194, 89, 41, 193, 182, 43, 187, 192, 224, 77, 103, 97, 177, 18, 219, 4, 9, 131, 171, 73, 26, 2, 57, 117, 65, 1, 165, 77, 56, 210, 103, 254, 125, 51, 149, 253, 255, 28, 114, 35, 194, 81, 238, 229, 183, 17, 48, 106, 233, 8, 192, 231, 53, 7, 215, 216, 33, 62, 141, 216, 228, 198, 63, 210, 28 } });

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Tenants_TenantId",
                table: "Payments",
                column: "TenantId",
                principalTable: "Tenants",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Tenants_TenantId",
                table: "Payments");

            migrationBuilder.DeleteData(
                table: "Manager",
                keyColumn: "Id",
                keyValue: new Guid("670dfbac-7729-42fa-afe2-c232a876a082"));

            migrationBuilder.AlterColumn<Guid>(
                name: "TenantId",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            migrationBuilder.AddColumn<Guid>(
                name: "ApartmentId",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "Tenant",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.InsertData(
                table: "Manager",
                columns: new[] { "Id", "ManagerName", "PasswordHash", "PasswordSalt" },
                values: new object[] { new Guid("0afe74fd-3f6c-40b4-a1eb-c7a382b9b380"), "admin", new byte[] { 193, 55, 138, 4, 7, 208, 103, 27, 193, 44, 0, 149, 59, 33, 219, 170, 232, 24, 45, 97, 76, 202, 162, 107, 210, 166, 128, 91, 186, 185, 169, 106, 244, 198, 163, 22, 11, 34, 194, 94, 200, 186, 218, 99, 202, 84, 28, 52, 53, 115, 244, 8, 147, 188, 15, 117, 16, 47, 100, 156, 199, 255, 218, 244 }, new byte[] { 16, 15, 160, 116, 108, 58, 90, 234, 108, 71, 191, 182, 134, 15, 73, 77, 90, 88, 233, 154, 2, 76, 168, 48, 18, 200, 215, 63, 146, 138, 182, 24, 50, 177, 94, 153, 121, 174, 194, 105, 51, 199, 90, 122, 95, 232, 71, 235, 20, 194, 118, 176, 110, 221, 183, 203, 133, 191, 4, 251, 141, 160, 150, 222, 155, 102, 149, 26, 82, 53, 90, 102, 27, 243, 87, 111, 127, 18, 240, 130, 46, 165, 161, 70, 108, 86, 237, 56, 173, 75, 228, 158, 9, 155, 52, 96, 28, 168, 150, 151, 253, 78, 9, 163, 37, 30, 73, 144, 58, 221, 121, 118, 254, 211, 90, 152, 212, 55, 75, 88, 75, 48, 177, 187, 245, 6, 119, 202 } });

            migrationBuilder.CreateIndex(
                name: "IX_Payments_ApartmentId",
                table: "Payments",
                column: "ApartmentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Apartments_ApartmentId",
                table: "Payments",
                column: "ApartmentId",
                principalTable: "Apartments",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Tenants_TenantId",
                table: "Payments",
                column: "TenantId",
                principalTable: "Tenants",
                principalColumn: "Id");
        }
    }
}
