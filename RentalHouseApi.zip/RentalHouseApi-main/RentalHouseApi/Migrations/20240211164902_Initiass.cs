﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentalHouseApi.Migrations
{
    /// <inheritdoc />
    public partial class Initiass : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Apartments_ApartmentId",
                table: "Payments");

            migrationBuilder.DeleteData(
                table: "Manager",
                keyColumn: "Id",
                keyValue: new Guid("d1bb89ae-61a9-4e0c-9fa7-682a0aad7929"));

            migrationBuilder.AlterColumn<Guid>(
                name: "ApartmentId",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            migrationBuilder.AddColumn<Guid>(
                name: "Tenant",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.InsertData(
                table: "Manager",
                columns: new[] { "Id", "ManagerName", "PasswordHash", "PasswordSalt" },
                values: new object[] { new Guid("44eebca8-3586-4b2f-b082-7f2b79a7e8cb"), "admin", new byte[] { 152, 181, 229, 202, 97, 8, 22, 255, 66, 105, 163, 152, 174, 106, 251, 5, 154, 31, 166, 8, 2, 226, 89, 221, 123, 83, 150, 117, 112, 131, 121, 36, 71, 101, 235, 99, 18, 255, 68, 179, 207, 152, 132, 215, 252, 144, 237, 202, 133, 120, 49, 136, 181, 221, 93, 23, 214, 92, 70, 187, 72, 26, 196, 19 }, new byte[] { 242, 66, 147, 217, 197, 154, 61, 248, 52, 112, 21, 245, 76, 230, 76, 124, 83, 170, 130, 102, 182, 84, 61, 226, 103, 251, 104, 156, 161, 65, 173, 43, 19, 192, 47, 166, 170, 174, 93, 47, 219, 254, 205, 109, 102, 80, 252, 58, 200, 237, 239, 158, 130, 59, 213, 228, 242, 121, 239, 122, 39, 175, 84, 14, 151, 86, 104, 126, 110, 2, 25, 127, 187, 180, 182, 169, 192, 92, 169, 184, 5, 22, 216, 108, 217, 13, 180, 246, 175, 244, 243, 230, 127, 220, 217, 215, 164, 15, 151, 47, 190, 240, 9, 210, 212, 44, 248, 213, 183, 72, 227, 165, 53, 34, 165, 93, 160, 8, 237, 169, 112, 244, 105, 69, 48, 206, 57, 238 } });

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Apartments_ApartmentId",
                table: "Payments",
                column: "ApartmentId",
                principalTable: "Apartments",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Payments_Apartments_ApartmentId",
                table: "Payments");

            migrationBuilder.DeleteData(
                table: "Manager",
                keyColumn: "Id",
                keyValue: new Guid("44eebca8-3586-4b2f-b082-7f2b79a7e8cb"));

            migrationBuilder.DropColumn(
                name: "Tenant",
                table: "Payments");

            migrationBuilder.AlterColumn<Guid>(
                name: "ApartmentId",
                table: "Payments",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);

            migrationBuilder.InsertData(
                table: "Manager",
                columns: new[] { "Id", "ManagerName", "PasswordHash", "PasswordSalt" },
                values: new object[] { new Guid("d1bb89ae-61a9-4e0c-9fa7-682a0aad7929"), "admin", new byte[] { 120, 2, 141, 247, 132, 170, 126, 61, 75, 102, 155, 3, 168, 46, 87, 141, 167, 48, 254, 241, 199, 199, 149, 151, 158, 122, 145, 156, 220, 194, 91, 159, 79, 217, 249, 73, 116, 64, 247, 24, 186, 112, 240, 227, 23, 17, 150, 3, 119, 30, 12, 20, 100, 68, 99, 29, 88, 45, 167, 166, 245, 36, 247, 197 }, new byte[] { 34, 183, 111, 27, 241, 214, 32, 255, 131, 115, 16, 238, 8, 77, 118, 175, 53, 178, 95, 211, 131, 231, 240, 124, 96, 96, 57, 5, 118, 102, 4, 187, 74, 210, 144, 207, 175, 108, 148, 185, 60, 64, 157, 84, 199, 12, 226, 167, 183, 232, 54, 171, 169, 190, 9, 23, 169, 159, 72, 182, 160, 99, 67, 229, 95, 138, 206, 69, 39, 138, 20, 86, 105, 197, 226, 9, 73, 42, 211, 7, 49, 39, 148, 5, 87, 78, 154, 52, 179, 251, 103, 215, 17, 12, 10, 48, 211, 156, 123, 19, 194, 184, 110, 42, 104, 34, 152, 157, 148, 127, 180, 123, 231, 237, 24, 196, 138, 197, 158, 158, 255, 75, 58, 232, 48, 126, 156, 32 } });

            migrationBuilder.AddForeignKey(
                name: "FK_Payments_Apartments_ApartmentId",
                table: "Payments",
                column: "ApartmentId",
                principalTable: "Apartments",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
